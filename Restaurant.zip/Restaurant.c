#include <stdio.h>
#include <sys/msg.h>

// define message types 
#define MSG_menu 1
#define MSG_order 2
#define MSG_order_ready 3

// create a structure to hold all the message data i.e menu, order, order ready 
struct message {
    long msg_type; // variable to hold message type
    char msg_text[100]; // variable to hold message text
};

// activity log for restaurant -> simple function to log activities, keep track of orders 
void log(const char *activity){
    // want to log activity and time implement file logging later
    int time;
    getttimeofday(&time);
    printf("Activity: %s at time: %d\n", activity, time);
}

// main function 
int main (){
    /* want to create a message queue to hold all the messages to be used by the restaurant processes. 
    */

    // create a key to be used for message queue -> this key is used to identify the message queue
    key_t key = ftok("restaurant.c", 65);

    // create a message queue to hold all the messages 
    // 0666 is the permission to read and write the message queue, IPC_CREAT is used to create the message queue if it does not exist
    int msgid = msgget(key, 0666 | IPC_CREAT);
    
    // check if the message queue was created successfully
    if (msgid == -1) {
        printf("Message queue creation failed\n");
        return 1;
    }
    else { // success message 
        printf("Message queue created successfully with id: %d\n", msgid);
    }

    // create a waiter process 
    pid_t waiter_pid = fork();
    // check if the fork was successful 
    if(waiter_pid == 0){
        // waiter process code 
        /* want to send the menu to the customer
        want to receive the order from the customer
        want to send the order to the kitchen 
        take each message and add it to the message queue then the other process can read from the message queue 
        */

        // create a message structure to hold the menu 
        struct message menu_msg;
        menu_msg.msg_type = MSG_menu; // set message type to menu
        fprintf(menu_msg.msg_text, "Menu: 1. Pizza 2. Burger 3. Pasta"); // set message text to menu items 
        msgsnd(msgid, &menu_msg, sizeof(menu_msg), 0); // send the menu to the customer

        // receive the order from the customer 
        struct message order_msg;
        msgrcv(msgid, &order_msg, sizeof(order_msg), MSG_order, 0); // receive the order from the customer
        printf("Waiter received order: %s\n", order_msg.msg_text); // print the order received
        log("Waiter received order from customer"); 

        // send the order to the kitchen
        msgsnd(msgid, &order_msg, sizeof(order_msg), 0); // send the order to the kitchen
        log("Waiter sent order to kitchen");
        printf("Waiter sent order to kitchen: %s\n", order_msg.msg_text); // print the order sent

        exit(0); // exit the waiter process
    }


    return 0; 
}